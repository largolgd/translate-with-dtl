# Configuration files

The engine is configured through six OSGi configuration files, one per theme, all under
`digital-factory-data/karaf/etc/`. The module ships each file with every setting at its default and a
comment for each; Jahia copies a file there the first time the module starts without it, and never
overwrites the copy afterwards (its first line is the `# default configuration` marker the extender looks
for). Edit the files, or use the provisioning API (`editConfiguration` with the theme's PID); fileinstall
applies a change without a restart. Avoid the Felix Web Console for these PIDs: it rewrites the file in a
typed syntax (`L"5"`, quoted strings) a `.cfg` file does not read back.

## Settings added by a later version

Since your copy of a file is never overwritten, a setting a later version adds would not reach it. The module
therefore completes each file at every start: a setting the file does not hold is appended at the end, at its
default, and the log names them — `[org.jahia.modules.formidable.<theme>] Added the settings missing from the
theme's file, at their defaults: [...]`. Nothing else changes: a value present in the file, edited or not, stays
as it is, your comments stay, and a line the module does not know is left in place. A setting you delete from a
file comes back at its default at the next start, which is the value the module applied without it anyway. The
[upgrade notes](upgrade-notes.md#settings-added-to-the-configuration-files) list the settings each version adds.
A configuration made without a file (the Felix console) is not completed.

## The six themes

| Theme | PID and file (`karaf/etc/<PID>.cfg`) | Settings | Read by |
|---|---|---|---|
| CAPTCHA | `org.jahia.modules.formidable.captcha` | `captchaSiteKey`, `captchaSecretKey`, `captchaScriptUrl`, `captchaWidgetVar`, `captchaTokenField`, `captchaVerifyUrl`, `captchaHttpConnectTimeoutSeconds`, `captchaHttpRequestTimeoutSeconds` | the widget in the page, the verification at submission — [CAPTCHA server-side validation](captcha-server-side-validation.md) |
| Uploads | `org.jahia.modules.formidable.uploads` | `uploadMaxFileSizeBytes`, `uploadMaxRequestSizeBytes`, `uploadMaxFileCount`, `uploadAllowedTypes` | the multipart parser, the early size guard, the e-mail action's attachment bound, the file field and its `accept` choicelist — [Allowed file types](#allowed-file-types) |
| Choice options | `org.jahia.modules.formidable.choiceOptions` | `optionsSourcesCacheTtlSeconds`, `optionsQueryMaxResults`; the sources, one file each (below) | the options sources a choice field may pick — [Choice field options sources](../architecture/choice-field-options-sources.md#declaring-sources-administrator) |
| Form actions | `org.jahia.modules.formidable.formActions` | `enableDevForwardTargets`, `forwardHttpConnectTimeoutSeconds`, `forwardHttpRequestTimeoutSeconds`; the forward targets, one file each (below) | the forward action and its target picker |
| Field actions | `org.jahia.modules.formidable.fieldActions` | `enableDevFieldActionEndpoints`, `fieldActionHttpConnectTimeoutSeconds`, `fieldActionHttpRequestTimeoutSeconds`, `fieldActionVerdictCacheTtlSeconds`, `fieldActionRateLimitPerMinute`, `fieldActionMaxValueLength`, `fieldActionMaxValuesPerField` | the calls of the field actions (and whether a development endpoint may be called) and the pre-check endpoint; the service a check calls is in its own module's configuration — [Field actions: services and limits](field-actions.md) |
| Forms import | `org.jahia.modules.formidable.formsImport` | `importButtonEnabled`, `maxFileSizeMb` | the **Import** button of the Results page and the bound on the export it takes — [Importing the forms and results of Jahia Forms](forms-import.md) |

The setting names are the ones of the single file of earlier builds but one — `uploadAllowedMimeTypes` is now
`uploadAllowedTypes`, since it takes extensions too — except two of the lists, which are now one file per
entry (below). Any other line copied from an old file into its theme's
file is read as it was; the migration below reads the renamed setting under its former name, does not carry a
list still at the former default — the new default holds the same seventeen types, written as extensions — and
carries an empty list, which meant any file until 0.5, as `*/*`. The PIDs are dotted on purpose — `org.jahia.modules.formidable-captcha`
would declare an instance of a factory configuration, which none of these is — so the six files sort
together in `karaf/etc/` and in the Felix console.

Each file is logged when it is read (`CaptchaConfigService configured: …`, `UploadsConfigService configured: …`,
and so on), with what was accepted; a refused entry — a target without HTTPS, an entry without an id — is
logged with its id and the reason, never a credential. A zero or negative
timeout or bound is refused and the default applies, with a warning naming the setting.

## Allowed file types

`uploadAllowedTypes` lists the file types a file field may accept, comma-separated. Each entry is an
extension (`pdf`, `.docx`), a MIME type (`application/pdf`), a wildcard (`image/*`), or `*/*` for any file.
An extension stands for the MIME type Apache Tika gives it, and a MIME alias stands for its canonical type (`audio/x-wav` is
`audio/vnd.wave`, the type Tika detects a WAV file as): the engine resolves every entry once, when it reads the
file, and logs what it resolved (`uploadAllowedTypes: read as [pdf = application/pdf, …]`); an entry that is
neither a MIME type nor an extension Tika knows is ignored, with a warning. From then on everything compares MIME
types, including the check of every uploaded file, whose type Tika detects from its content and name: `txt`
allows `text/plain`, the type Tika gives any plain-text file whatever its extension (`.cnd`, `.pom`).

What that detection proves depends on the format. For a format Tika recognises by its content — PDF, the image
formats, the video and audio containers, XML documents, plain text — the content decides and a name cannot pass
one off as another. For a format built on a container, the engine (which embeds `tika-core` alone, with no
container detector) checks the **family** by content — a zip, an OLE2 compound file — and takes the **kind** from
the name: any zip named `.docx`, `.xlsx` or `.odt` is read as that document, a jar named `.zip` as a zip, an
old binary file named `.doc` or `.xls` as that document. Listing `docx` therefore lets through any zip a visitor
names `.docx`. Checking the kind by content would need Tika's container detectors (`tika-parsers`), a heavier
dependency the module does not take.

An extension shared by several types stands for one of them only — `ogg` is read as `audio/vorbis`, an Ogg video
is `ogv` (`video/ogg`). Give the MIME type when the extension is ambiguous. Tika's registry of the version the
module embeds says which type each extension stands for:
[tika-mimetypes.xml of Tika 3.3.2](https://github.com/apache/tika/blob/3.3.2/tika-core/src/main/resources/org/apache/tika/mime/tika-mimetypes.xml)
(search for `*.ogg`). The default list, `jpg,png,gif,webp,pdf,doc,docx,xls,xlsx,odt,ods,txt,csv,mp4,webm,ogv,mkv`,
holds no ambiguous extension.

For audio and video, Tika detects what is inside the container, which the file's name does not say: an Ogg video
named `.ogv` is detected as `video/theora`, an Opus track named `.oga` as `audio/opus`. Tika's registry declares
these kinds of `video/ogg` and `audio/ogg`, so an audio or video file is also accepted when its detected type is a
kind of the type its name stands for, and that type is listed as such — `ogv` or `video/ogg`, not only
`video/*`. Every other type is matched exactly: elsewhere the registry's "kind of" means "readable as" — an XHTML
page, detected by its content, is a kind of `application/xml` — and listing `xml` must not let it through.

The list is the whole of what a file field may accept:

- a field whose **Accept** setting is empty accepts every listed type;
- a field whose **Accept** setting names types keeps those still listed — a type removed from the list is no
  longer offered to the visitor nor accepted by the server, and a warning names the field and the type each time
  the field is rendered afresh — not when the page is served from the cache —
  (`Field '<path>' accepts '<type>', which the uploads configuration does not allow: ignored`, or `which is not a
  file type` for a stored value that names none). Until the field is edited again, the content keeps the value and
  the field honours it again if the type is listed again; once a contributor saves the field in the Content
  Editor, the setting holds only the types still listed — the editor offers no other — and the removed type is
  gone for good;
- **removing a type therefore changes what fields accept, and can widen it.** A field that accepted only removed
  types accepts no file until it is edited, then — its **Accept** setting emptied by the save — every listed type,
  or any file under `*/*`. Replacing the list by `*/*` alone removes every specific type in that sense: a field
  restricted to PDFs keeps its restriction only if `pdf` stays listed next to `*/*`. Before removing a type, look for the file fields that name it (the warning above lists
  them as their pages render) and decide what each should accept instead;
- `*/*` accepts any file, whatever type Tika detects — it holds the types a future Tika adds, where a list of
  wildcards would not: a field without types then restricts nothing, in the visitor's picker nor on the server,
  and a field with types keeps its own. Any file includes HTML pages and SVG images: the results screens never
  open them as a page, but a file's own address opened in a browser displays it on the Jahia origin — list the types
  your forms need rather than `*/*` when you can;
- an empty list accepts no file at all: every file field refuses every file, and the engine says so when it reads
  the file, giving `*/*` as the way to accept any file.

The server applies a change at once. Pages already rendered keep offering the former list — in the file picker, the
formats they list and their own check before sending — until the site's cache is flushed (jContent, or the
`flushSiteCache` GraphQL mutation): a type removed is then refused only when the form is sent, a type added is
refused by the page before anything is sent.

The **Accept** setting offers the listed types, each with the module's translated wording where the module ships
one (the seventeen default types, and the top-level wildcards: "Any image (image/*)"), else with a label made from
the type — its acronym or extension, then the extension: "ZIP (.zip)". `*/*` is never offered — a field without
types already accepts any file —: in its place the setting offers a wildcard for each top-level type of Tika's
registry (`application/*`, `audio/*`, `chemical/*`, `image/*`, `message/*`, `model/*`, `multipart/*`, `text/*`,
`video/*`, `x-conference/*` in Tika 3.3.2), beside the other listed types. Those wildcards narrow a field coarsely
only — `application/*` takes a PDF as well as an archive or an executable —: to let contributors restrict a field
to PDFs or to Word documents, list those types next to `*/*` (`*/*,pdf,docx`), and the setting offers them too. An administrator cannot give a type of their own a translated label; a developer adds
the key `fmdb_inputFile.accept.<mime/type>` to the module's resource bundle.

## The lists: one file per entry

Two settings are lists an administrator adds to and removes from: the options sources a choice field may
take its options from, and the services a forward action may send a submission to. Each entry is a file of its
own, next to its theme's file:

| Entry | File (`karaf/etc/`) | Settings |
|---|---|---|
| Options source | `org.jahia.modules.formidable.choiceOptions.source-<id>.cfg` | `id`, `label`, `initializerKey`, `param` — [Choice field options sources](../architecture/choice-field-options-sources.md#declaring-sources-administrator) |
| Forward target | `org.jahia.modules.formidable.formActions.target-<id>.cfg` | `id`, `label`, `url`, `development` — [Form submission flow](../architecture/form-submission-flow.md#forwardaction--target-registry) |

The `id` setting is required: it is what the content stores (a choice field's source, a forward action's
target), so keep it once contributors use it. It is letters, digits, dashes and underscores
only — it names the file, and Jahia's configuration service finds a file by the start of its name, so `crm.eu`
would collide with `crm`: an entry with another id counts for nothing, with a warning. The `-<id>` of the file name is only
a convention for the reader — the `id` setting is what counts — and two files declaring the same id keep one,
with a warning naming the configuration kept and the one ignored. `label` is what the editor's picker shows, the
id when it is empty. Remove a file to remove the entry — except a file a module ships (below): Jahia copies it
back at the module's next start whenever it is missing, so empty its `id` instead, and the entry counts for
nothing. Whether Jahia leaves your copy alone is decided by the module's file, not yours: a shipped file that
carries a `# default configuration` line is copied only while missing, so your edits stay, the emptied `id`
included; a shipped file without that line is written back at every start of the module, and only the module
can retire it. A forward target:

```properties
# karaf/etc/org.jahia.modules.formidable.formActions.target-crm-prod.cfg
id=crm-prod
label=CRM (production)
url=https://crm.example.com/hook
```

A forward target marked `development=true` — a service over plain HTTP on `localhost` or
`host.docker.internal`, such as the samples module's `localhost` target — is honoured only while
`enableDevForwardTargets` is on (`false` by default; never in production), and a development id never shadows a
standard one.

Three ways to add an entry, all ending in the same file:

- **Write the file** in `karaf/etc/`; fileinstall loads it without a restart.
- **The provisioning API**: `editConfiguration` with the factory PID and the id —
  `org.jahia.modules.formidable.formActions.target-crm-prod` — writes that file.
- **The Felix console**: the factory's **+** button (*Formidable — Form actions — Forward target*, *Formidable —
  Choice options — Source*) opens a form of the entry's settings. The console keeps what it creates in its own storage, out of
  `karaf/etc/`; the module stores it again as a file through Jahia's configuration service, then deletes the
  console's copy — the log says `The forward target 'crm-prod' created in the console is now the file …`. The
  entry then shows in the console under a generated PID, the file carrying the id. Without an id nothing is
  stored and the log asks for one; an id already configured keeps its file, and the console's entry is left for
  you to delete.

A module may ship entries of its own, as the samples module ships the `country` source and the `localhost` target: a file under
`META-INF/configurations/`, copied to `karaf/etc/` the first time the module starts without it.

## Upgrading from the single file

Until 0.5 the engine read one PID, `org.jahia.modules.formidable`, whether from
`karaf/etc/org.jahia.modules.formidable.cfg` (written by the provisioning API, or by hand) or from ConfigAdmin
alone (the Felix console). Neither is read any more, and both are carried over at the first start of a
version with the themes:

1. Jahia copies the six theme files to `karaf/etc/` and fileinstall loads them, every setting at its default.
2. As soon as a theme's configuration comes from its file, the theme reads the old configuration through
   ConfigAdmin and copies every setting of the theme it holds at a value other than the default — as long as
   the theme's file still holds the default for it. A value already set in the new file wins, with a warning
   naming the setting. The values are written into the theme's file with a marker (`formidable.migratedFrom`);
   a theme with nothing to carry — a new installation, or an old configuration at its defaults for that theme —
   gets the marker too. The migration therefore runs once per theme, whatever it finds: an old configuration that
   appears later (a provisioning script still writing `org.jahia.modules.formidable`) is never read. The log shows
   `[org.jahia.modules.formidable.<theme>] Carried over from org.jahia.modules.formidable into the theme's file: [...]`,
   or `Nothing of org.jahia.modules.formidable to carry over`.
3. The old file, when there is one, gets a first line saying it is no longer read, whether or not anything was
   carried from it. It is never deleted — the administrator wrote it — and can be removed by hand once the five
   files are checked.
4. A write that fails (a persistence directory full or read-only) is tried three times in all, thirty seconds
   apart. Meanwhile the settings to carry stay in force — a CAPTCHA key or a forward target of the old file keeps
   working, the new file's defaults do not take over. After the third failure the theme's file rules as it stands
   and the log says `Gave up carrying the settings of org.jahia.modules.formidable over … re-enter the settings of
   this theme in it`. A restart starts the three attempts over.

**How to check**: open the six files after the upgrade. A setting that was not at its default before the
upgrade is there, in its theme's file, on a line without a comment; the marker line
`formidable.migratedFrom=org.jahia.modules.formidable` is the trace that the migration wrote the file. A
setting the old configuration held that its theme's file shows at the default was either at its default (then
it was not copied) or lost to a write that kept failing (then the log says so): re-enter it.

**The lists of earlier builds** — `optionsSources`, `forwardTargets` and `devForwardTargets`, one entry per
line (`id|Label|…`) — become one file per
line the first time their theme is read from its file, whether the lines sit in the theme's file (where the
step above carried them) or still in the old PID; the lines of `devForwardTargets` become entries with
`development=true`. An id an entry already declares — in its `id` setting, whatever its file is called — keeps
that entry, and its line is not carried. The settings are then
removed from the theme's file, which gets the marker `formidable.linesConverted=true`, and the log lists the
ids: `The forward target lines became one file each, karaf/etc/org.jahia.modules.formidable.formActions.target-<id>.cfg: [...]`.
A malformed line is logged and skipped. A line whose id holds anything but letters, digits, dashes and
underscores — a dot, a space, which earlier builds accepted — cannot become a file: the other lines are converted,
but the lines stay where they were found (the theme's file or `org.jahia.modules.formidable`), no marker is
written, and an error names the ids and that configuration at each change. The ids already converted are kept in
the theme's file (`formidable.linesConvertedIds`): a later run leaves them alone, so an entry you delete meanwhile
does not come back. Declare each such entry as a file
with a valid id, point the forms that store the former id at the new one — the choice fields' source, the
forward actions' target —, then remove the lines. A conversion that fails is tried again at the theme's next change. The
same happens on an instance that ran a 0.5 snapshot build, whose theme files still held the lists.

**In a cluster**, each node reads its own `karaf/etc`: the migration runs on every node at its first start, from
that node's old configuration. Keep the six files, and the entry files, the same on every node, as for any file of `karaf/etc`.
