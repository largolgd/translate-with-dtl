import {type RefObject, useEffect} from 'react';
import {clearAllFieldErrors, clearFieldError, hasFieldError, isCustomErrorOnly, resolveValidationMessage, showFieldError} from '~/utils/validationUtils';

type FormInputElement = HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;

interface UseCustomValidationOptions {
	formRef: RefObject<HTMLFormElement | null>;
}

export function useCustomFormValidation({formRef}: UseCustomValidationOptions) {
	useEffect(() => {
		const form = formRef.current;
		if (!form) return;

		const handleInvalid = (e: Event) => {
			e.preventDefault();
			const input = e.target as FormInputElement;
			showFieldError(input, resolveValidationMessage(input));
		};

		const handleInput = (e: Event) => {
			const input = e.target as FormInputElement;
			if (input.validity.valid) {
				clearFieldError(input);
			}
		};

		const handleFormReset = () => {
			clearAllFieldErrors(form);
		};

		form.addEventListener('invalid', handleInvalid, true);
		form.addEventListener('input', handleInput);
		form.addEventListener('change', handleInput);
		form.addEventListener('reset', handleFormReset);

		return () => {
			form.removeEventListener('invalid', handleInvalid, true);
			form.removeEventListener('input', handleInput);
			form.removeEventListener('change', handleInput);
			form.removeEventListener('reset', handleFormReset);
		};
	}, [formRef]);
}

export function validateInputs(container: HTMLElement): boolean {
	const allInputs = Array.from(container.querySelectorAll<FormInputElement>('input, select, textarea'));
	const seenGroups = new Set<string>();
	const inputs = allInputs.filter(input => {
		// Mirror the browser's own constraint validation: a control barred from it
		// (disabled — which is how conditional logic neutralizes a hidden field —
		// or a hidden-type input) must not block the submission. Its validity state
		// can be stale by design: a required checkbox group keeps its "select at
		// least one" customValidity while logic has it hidden and disabled, and no
		// change event will ever clear it there.
		if (!input.willValidate) return false;
		if (!(input instanceof HTMLInputElement)) return true;
		if (input.type !== 'radio' && input.type !== 'checkbox') return true;
		if (!input.name) return true;

		const groupKey = `${input.type}:${input.name}`;
		if (seenGroups.has(groupKey)) return false;
		seenGroups.add(groupKey);
		return true;
	});

	let firstInvalid: HTMLElement | null = null;
	let allValid = true;

	inputs.forEach(input => {
		if (!input.validity.valid) {
			// An error another client drew under a control it holds invalid through customValidity alone — a
			// field action's refusal, the contributor's HTML — stays: redrawing it from validationMessage
			// would turn it into its plain text at the moment the visitor most needs it.
			if (!(isCustomErrorOnly(input) && hasFieldError(input))) {
				showFieldError(input, resolveValidationMessage(input));
			}
			if (!firstInvalid) firstInvalid = input;
			allValid = false;
		} else {
			clearFieldError(input);
		}
	});

	if (firstInvalid) (firstInvalid as HTMLElement).focus();
	return allValid;
}
