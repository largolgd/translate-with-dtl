package org.jahia.modules.formidable.engine.config;

import org.jahia.modules.formidable.engine.config.common.ConfigurationAttributes;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.util.Dictionary;
import java.util.Map;
import java.util.TreeMap;

/**
 * Writes into a theme's file every setting it does not hold, at its built-in default. Jahia copies a module's
 * configuration file once and keeps the administrator's copy as edited, so a setting added by a later version never
 * reaches an existing installation's file: the module applies its default all the same, but the administrator reading
 * the file does not know the setting exists. The completion only adds: a value present in the file, edited or not, is
 * never touched, and a key the module does not know is never removed. It runs once per start of the theme's service,
 * the first time the theme's configuration comes from its file ({@value ConfigurationAttributes#FILEINSTALL_FILENAME},
 * the one fileinstall persists the update into): a line the administrator deletes later, while the module runs, stays
 * deleted until the next start — the file is never rewritten under an edit. It writes only when something is missing.
 * A write that fails, whatever the failure, is logged and tried again at the next callback, never fatal to the theme:
 * meanwhile the module applies the defaults the write would have written.
 */
final class MissingSettingsCompletion {

    private static final Logger log = LoggerFactory.getLogger(MissingSettingsCompletion.class);

    private final String pid;
    /** The theme's settings and their defaults, as the strings written into a configuration. */
    private final Map<String, Object> defaults;
    /** Whether this start's completion is over: the file was complete, or completed. */
    private boolean done;

    MissingSettingsCompletion(String pid, Class<? extends Annotation> definition) {
        this.pid = pid;
        this.defaults = ConfigurationAttributes.defaultStringsOf(definition);
    }

    /**
     * Writes the settings missing from the theme's configuration, when it comes from its file, ConfigurationAdmin is
     * bound and this start's completion is not over.
     *
     * @param properties the raw properties DS handed over, null when the service is driven without a file (the tests)
     * @return the settings written, empty when nothing was missing, nothing was due or the write failed
     */
    synchronized Map<String, Object> run(ConfigurationAdmin admin, Map<String, Object> properties) {
        if (done || admin == null || properties == null || !properties.containsKey(ConfigurationAttributes.FILEINSTALL_FILENAME)) {
            return Map.of();
        }
        try {
            Configuration configuration = admin.getConfiguration(pid, "?");
            // ConfigurationAdmin's copy, never the properties DS handed over: those always hold every setting, the
            // component description carrying the definition's defaults as component properties (bnd writes them).
            // The caller's private copy (Configuration#getProperties): edited in place, then written back.
            Dictionary<String, Object> updated = configuration.getProperties();
            if (updated == null) {
                return Map.of();
            }
            Map<String, Object> added = new TreeMap<>();
            defaults.forEach((setting, value) -> {
                if (updated.get(setting) == null) {
                    updated.put(setting, value);
                    added.put(setting, value);
                }
            });
            if (added.isEmpty()) {
                done = true;
                return Map.of();
            }
            configuration.update(updated);
            done = true;
            log.info("[{}] Added the settings missing from the theme's file, at their defaults: {}", pid, added.keySet());
            return added;
        } catch (IOException | RuntimeException e) {
            log.error("[{}] Could not add the settings missing from the theme's file; their defaults apply all the same", pid, e);
            return Map.of();
        }
    }
}
