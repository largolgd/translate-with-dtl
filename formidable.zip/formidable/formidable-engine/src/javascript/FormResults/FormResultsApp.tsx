import React, {useCallback, useEffect, useRef, useState, useMemo} from 'react';
import {useQuery} from '@apollo/client';
import {Button, DeletePermanently, Download, Link, Loader, Reload, Typography, Upload} from '@jahia/moonstone';
import {useTranslation} from 'react-i18next';
import {GET_FORM_RESULTS_LIST, GET_FORM_FIELD_LABELS, GET_FORMS_IN_EDIT} from './graphql';
import {DeleteResultsDialog} from './delete';
import {ExportResultsDialog} from './export';
import {AttachResultsDialog, fetchSettings, ImportResultsDialog, type ImportJob, type ImportSettings} from './import';
import {FormResultsList, FormStatusChip, SubmissionDetailPanel, SubmissionsTable} from './components';
import type {FormResultsNode, SubmissionRow} from './FormResults.utils';
import {
    buildFormsInEditQuery,
    currentSiteKey,
    EMPTY_FORM_FIELDS,
    formResultsLabel,
    formStatus,
    labelsFormOf,
    isMissingInLive,
    parseFormFields,
    uiContext,
    withEditForms
} from './FormResults.utils';

export const FormResultsApp = () => {
    const {t} = useTranslation('formidable-engine');
    const siteKey = currentSiteKey();
    const language = uiContext().uilang || 'en';
    const resultsPath = `/sites/${siteKey}/formidable-results`;

    const [selectedFormResultsId, setSelectedFormResultsId] = useState<string | null>(null);
    const [selectedSubmission, setSelectedSubmission] = useState<SubmissionRow | null>(null);
    const [isExportDialogOpen, setIsExportDialogOpen] = useState(false);
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    const [isAttachDialogOpen, setIsAttachDialogOpen] = useState(false);
    const [isRefreshing, setIsRefreshing] = useState(false);
    // The import of another form system's forms and results, offered when the setting is on and the user
    // administers the site (docs/architecture/forms-import.md). A job left running or unread reopens.
    const [importSettings, setImportSettings] = useState<ImportSettings | null>(null);
    const [importDialog, setImportDialog] = useState<{open: boolean; job: ImportJob | null}>({open: false, job: null});
    useEffect(() => {
        if (!siteKey) {
            return;
        }
        fetchSettings(siteKey)
            .then(settings => {
                setImportSettings(settings);
                if (settings.job) {
                    setImportDialog({open: true, job: settings.job});
                }
            })
            .catch(() => {
                setImportSettings(null);
            });
    }, [siteKey]);
    const [refreshSelectedForm, setRefreshSelectedForm] = useState<(() => Promise<unknown>) | null>(null);

    // errorPolicy 'all': the list must survive one entry whose form reference cannot be resolved. A
    // dangling weak reference normally answers refNode: null, but Jahia has been seen throwing
    // ItemNotFoundException on it for an unpublished form (the live path still known, the node gone),
    // which with the default policy voided the whole list. With the field left null, the entry reads
    // as missing in live and the EDIT lookup tells unpublished from deleted, as for any other.
    const {loading, error, data, refetch: refetchForms} = useQuery(GET_FORM_RESULTS_LIST, {
        variables: {resultsPath, workspace: 'LIVE', language},
        fetchPolicy: 'network-only',
        errorPolicy: 'all',
        skip: !siteKey
    });

    const liveForms: FormResultsNode[] = useMemo(() => data?.jcr?.nodeByPath?.children?.nodes ?? [], [data]);
    // The entries whose form is not in live are told apart — unpublished or deleted — by one lookup in EDIT.
    const formsQuery = useMemo(
        () => buildFormsInEditQuery(liveForms.filter(isMissingInLive).map(form => form.parentForm?.value ?? '')),
        [liveForms]
    );
    const {data: editFormsData} = useQuery(GET_FORMS_IN_EDIT, {
        variables: {formsQuery: formsQuery!, language},
        skip: !formsQuery,
        fetchPolicy: 'network-only'
    });
    const forms = useMemo(
        () => withEditForms(liveForms, formsQuery ? editFormsData?.jcr?.nodesByQuery?.nodes : []),
        [liveForms, formsQuery, editFormsData]
    );
    const selectedForm = forms.find(f => f.uuid === selectedFormResultsId) ?? null;
    const selectedFormUuid = selectedForm?.uuid ?? null;
    const selectedFormLabel = selectedForm ? formResultsLabel(selectedForm) : '';
    // One Delete button for both deletions: the submissions of a range, or the whole entry. The
    // user needs the rights of both — administrative access today, the results-reader role carrying
    // none of them (docs/administration/results-permissions.md, "Deletion permissions").
    const canDeleteSelectedForm = Boolean(
        selectedForm?.canRemoveNode &&
        selectedForm?.submissionsContainer?.nodes?.[0]?.canRemoveNode &&
        selectedForm?.submissionsContainer?.nodes?.[0]?.canRemoveChildNodes
    );

    const labelsForm = labelsFormOf(selectedForm);
    const formUuid = labelsForm?.uuid;
    const {data: fieldLabelsData} = useQuery(GET_FORM_FIELD_LABELS, {
        variables: {formUuid: formUuid!, language, optionsLanguage: language, workspace: labelsForm?.workspace ?? 'LIVE'},
        skip: !formUuid,
        fetchPolicy: 'cache-first'
    });
    const formFields = useMemo(() => (formUuid ? parseFormFields(fieldLabelsData) : EMPTY_FORM_FIELDS), [formUuid, fieldLabelsData]);

    useEffect(() => {
        // eslint-disable-next-line @eslint-react/hooks-extra/no-direct-set-state-in-use-effect -- deliberate reset when the selected form changes
        setSelectedSubmission(null);
    }, [selectedFormUuid]);

    useEffect(() => {
        // eslint-disable-next-line @eslint-react/hooks-extra/no-direct-set-state-in-use-effect -- deliberate reset when the selected form changes
        setIsExportDialogOpen(false);
        // eslint-disable-next-line @eslint-react/hooks-extra/no-direct-set-state-in-use-effect -- deliberate reset when the selected form changes
        setIsDeleteDialogOpen(false);
    }, [selectedFormUuid]);

    // The arrow keys cross the page: right from the list lands on the table — the selected submission, or the
    // first one, selected on the way (the table registers that move, it alone knows its rows) — and left from
    // the table lands on the selected form, or the first.
    const contentRef = useRef<HTMLDivElement | null>(null);
    const enterTableRef = useRef<(() => void) | null>(null);
    const handleRegisterEnter = useCallback((enter: (() => void) | null) => {
        enterTableRef.current = enter;
    }, []);
    const focusTable = useCallback(() => {
        enterTableRef.current?.();
    }, []);
    const focusList = useCallback(() => {
        const content = contentRef.current;
        if (!content) {
            return;
        }

        (content.querySelector<HTMLElement>('[data-sel-role="form-results-entry"][aria-pressed="true"]')
            ?? content.querySelector<HTMLElement>('[data-sel-role="form-results-entry"]'))?.focus({preventScroll: true});
    }, []);

    const handleRegisterRefresh = useCallback((refresh: (() => Promise<unknown>) | null) => {
        setRefreshSelectedForm(() => refresh);
    }, []);

    const handleRefresh = async () => {
        if (!selectedForm || !refreshSelectedForm) {
            return;
        }

        setIsRefreshing(true);
        try {
            await Promise.all([refetchForms(), refreshSelectedForm()]);
        } finally {
            setIsRefreshing(false);
        }
    };

    const handleDeleteSuccess = async (entryRemoved: boolean) => {
        setSelectedSubmission(null);

        if (entryRemoved) {
            // The entry is gone: nothing to refresh under it, the list alone is re-read.
            setSelectedFormResultsId(null);
            await refetchForms();
            return;
        }

        if (!selectedForm || !refreshSelectedForm) {
            await refetchForms();
            return;
        }

        setIsRefreshing(true);
        try {
            await Promise.all([refetchForms(), refreshSelectedForm()]);
        } finally {
            setIsRefreshing(false);
        }
    };

    // The entry may have been renamed, merged into another or removed: the selection goes with the list re-read.
    const handleAttached = async () => {
        setSelectedSubmission(null);
        setSelectedFormResultsId(null);
        await refetchForms();
    };

    if (!siteKey) {
        return <Typography>{t('formResults.error.noSite')}</Typography>;
    }

    // The button opens on the job the site has, running or unread, which may have started since the page loaded.
    const openImportDialog = async () => {
        try {
            const settings = await fetchSettings(siteKey);
            setImportSettings(settings);
            setImportDialog({open: true, job: settings.job ?? null});
        } catch {
            setImportDialog({open: true, job: null});
        }
    };
    const importButton = importSettings?.allowed && (
        <Button
            variant="ghost"
            icon={<Upload/>}
            label={t('formResults.actions.import')}
            title={t('formResults.actions.importTitle')}
            data-sel-role="import-results"
            onClick={openImportDialog}
        />
    );
    const importDialogElement = importSettings && importDialog.open && (
        <ImportResultsDialog
            siteKey={siteKey}
            settings={importSettings}
            initialJob={importDialog.job}
            onClose={async imported => {
                setImportDialog({open: false, job: null});
                if (imported) {
                    await refetchForms();
                }
            }}
        />
    );
    // An empty site is where an import starts: the button stays reachable with no entry to list, whether
    // the results root is empty or does not exist yet.
    const emptyPage = () => (
        <div style={{display: 'flex', flexDirection: 'column', height: '100%', width: '100%'}}>
            {importButton && (
                <div style={{display: 'flex', alignItems: 'center', gap: '8px', padding: '12px 24px', borderBottom: '1px solid var(--color-gray_light40)', backgroundColor: 'var(--color-light)'}}>
                    {importButton}
                </div>
            )}
            <div data-sel-role="form-results-empty" style={{display: 'flex', justifyContent: 'center', alignItems: 'center', flex: 1, flexDirection: 'column', gap: '1rem', padding: '48px', textAlign: 'center'}}>
                <Typography variant="heading" weight="bold">{t('formResults.empty.noForms')}</Typography>
                <Typography>{t('formResults.empty.noFormsDescription')}</Typography>
            </div>
            {importDialogElement}
        </div>
    );

    if (loading) {
        return (
            <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%'}}>
                <Loader size="big"/>
            </div>
        );
    }

    // An error with no data at all is fatal; one that came with the list (errorPolicy 'all') is not.
    if (error && !data?.jcr?.nodeByPath) {
        if (error.graphQLErrors?.some(e => e.message?.includes('javax.jcr.PathNotFoundException'))) {
            return emptyPage();
        }

        return <Typography color="danger">{error.message}</Typography>;
    }

    if (forms.length === 0) {
        return emptyPage();
    }

    return (
        <div style={{display: 'flex', flexDirection: 'column', height: '100%', width: '100%', minWidth: 0, overflow: 'hidden'}}>
            <div
                style={{
                    padding: '24px 24px 16px',
                    borderBottom: '1px solid var(--color-gray_light40)',
                    backgroundColor: 'var(--color-light)'
                }}
            >
                <Typography variant="heading" weight="bold">
                    {t('formResults.nav.title')}
                </Typography>
                {/* Always one line below the title, as tall as the chip: the header must not change height
                    when an entry is selected or deselected. */}
                <div style={{display: 'flex', alignItems: 'center', gap: '8px', marginTop: '4px', minHeight: '24px'}}>
                    {selectedFormLabel && (
                        <Typography variant="body" style={{color: 'var(--color-gray)'}}>
                            {selectedFormLabel}
                        </Typography>
                    )}
                    {selectedForm && <FormStatusChip status={formStatus(selectedForm)}/>}
                </div>
            </div>

            <div
                style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    padding: '12px 24px',
                    borderBottom: '1px solid var(--color-gray_light40)',
                    backgroundColor: 'var(--color-light)'
                }}
            >
                <Button
                    variant="ghost"
                    icon={<Download/>}
                    label={t('formResults.actions.export')}
                    title={t('formResults.actions.exportTitle')}
                    data-sel-role="export-results"
                    isDisabled={!selectedForm}
                    onClick={() => setIsExportDialogOpen(true)}
                />
                {importSettings?.admin && selectedForm?.imported && (
                    <Button
                        variant="ghost"
                        icon={<Link/>}
                        label={t('formResults.actions.attach')}
                        title={t('formResults.actions.attachTitle')}
                        data-sel-role="attach-results"
                        onClick={() => setIsAttachDialogOpen(true)}
                    />
                )}
                {canDeleteSelectedForm && (
                    <Button
                        variant="ghost"
                        color="danger"
                        icon={<DeletePermanently/>}
                        label={t('formResults.actions.delete')}
                        title={t('formResults.actions.deleteTitle')}
                        data-sel-role="delete-results"
                        isDisabled={!selectedForm}
                        onClick={() => setIsDeleteDialogOpen(true)}
                    />
                )}
                <Button
                    variant="ghost"
                    icon={<Reload/>}
                    label={t('formResults.actions.refresh')}
                    isDisabled={!selectedForm || !refreshSelectedForm}
                    isLoading={isRefreshing}
                    onClick={handleRefresh}
                />
                {importButton}
            </div>

            <div
                ref={contentRef}
                style={{
                    display: 'flex',
                    flex: 1,
                    minHeight: 0,
                    minWidth: 0,
                    overflow: 'hidden',
                    gap: '16px',
                    padding: '16px',
                    backgroundColor: 'var(--color-gray_light40)'
                }}
            >
                <FormResultsList
                    forms={forms}
                    selectedId={selectedForm?.uuid ?? ''}
                    // A click on the selected entry deselects it: the list is a toggle, not a radio.
                    onSelect={id => setSelectedFormResultsId(current => (current === id ? null : id))}
                    onMoveRight={focusTable}
                />
                <div role="main" style={{display: 'flex', flex: '1 1 0', minWidth: 0, gap: '1px', overflow: 'hidden', backgroundColor: 'var(--color-gray_light40)'}}>
                    {selectedForm ? (
                        <div style={{flex: '1 1 0', minWidth: 0, overflow: 'hidden'}}>
                            <SubmissionsTable
                                formResults={selectedForm}
                                fieldOrder={formFields.order}
                                selectedSubmission={selectedSubmission}
                                onSelectSubmission={setSelectedSubmission}
                                onRegisterRefresh={handleRegisterRefresh}
                                onMoveLeft={focusList}
                                onRegisterEnter={handleRegisterEnter}
                            />
                        </div>
                    ) : (
                        <div style={{flex: '1 1 0', minWidth: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: 'var(--color-light)'}}>
                            <Typography variant="heading">
                                {t('formResults.empty.selectForm')}
                            </Typography>
                        </div>
                    )}
                    {selectedSubmission && (
                        <SubmissionDetailPanel
                            submission={selectedSubmission}
                            formFields={formFields}
                            onClose={() => setSelectedSubmission(null)}
                        />
                    )}
                </div>
            </div>
            {selectedForm && isExportDialogOpen && (
                <ExportResultsDialog
                    formResults={selectedForm}
                    onClose={() => setIsExportDialogOpen(false)}
                />
            )}
            {selectedForm && isAttachDialogOpen && (
                <AttachResultsDialog
                    siteKey={siteKey}
                    formResults={selectedForm}
                    onClose={async attached => {
                        setIsAttachDialogOpen(false);
                        if (attached) {
                            await handleAttached();
                        }
                    }}
                />
            )}
            {selectedForm && canDeleteSelectedForm && isDeleteDialogOpen && (
                <DeleteResultsDialog
                    formResults={selectedForm}
                    onClose={() => setIsDeleteDialogOpen(false)}
                    onDeleted={handleDeleteSuccess}
                />
            )}
            {importDialogElement}
        </div>
    );
};
