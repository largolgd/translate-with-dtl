import {gql} from '@apollo/client';
import {JCR_NODE_IDENTITY} from '../../graphql';

export const GET_FORM_RESULTS_LIST = gql`
    ${JCR_NODE_IDENTITY}
    query GetFormResultsList($resultsPath: String!, $workspace: Workspace = LIVE, $language: String!) {
        jcr(workspace: $workspace) {
            nodeByPath(path: $resultsPath) {
                ...JcrNodeIdentity
                children(typesFilter: {types: ["fmdb:formResults"]}) {
                    nodes {
                        ...JcrNodeIdentity
                        displayName(language: $language)
                        canRemoveNode: hasPermission(permissionName: "jcr:removeNode")
                        submissionsContainer: children(names: ["submissions"]) {
                            nodes {
                                ...JcrNodeIdentity
                                canRemoveNode: hasPermission(permissionName: "jcr:removeNode")
                                canRemoveChildNodes: hasPermission(permissionName: "jcr:removeChildNodes")
                            }
                        }
                        parentForm: property(name: "parentForm") {
                            value
                            refNode {
                                ...JcrNodeIdentity
                                displayName(language: $language)
                            }
                        }
                        imported: isNodeType(type: {types: ["fmdbmix:importedResults"]})
                    }
                }
            }
        }
    }
`;

export const GET_SUBMISSIONS = gql`
    ${JCR_NODE_IDENTITY}
    query GetSubmissions(
        $submissionsQuery: String!
        $limit: Int!
        $offset: Int!
        $workspace: Workspace = LIVE
    ) {
        jcr(workspace: $workspace) {
            nodesByQuery(
                query: $submissionsQuery
                queryLanguage: SQL2
                limit: $limit
                offset: $offset
            ) {
                pageInfo {
                    totalCount
                    hasNextPage
                }
                nodes {
                    ...JcrNodeIdentity
                    created: property(name: "jcr:created") {
                        value
                    }
                    origin: property(name: "origin") {
                        value
                    }
                    locale: property(name: "locale") {
                        value
                    }
                    referer: property(name: "referer") {
                        value
                    }
                    timeZone: property(name: "timeZone") {
                        value
                    }
                    data: children(names: ["data"]) {
                        nodes {
                            ...JcrNodeIdentity
                            properties {
                                name
                                value
                                values
                            }
                        }
                    }
                    files: children(names: ["files"]) {
                        nodes {
                            ...JcrNodeIdentity
                            children {
                                nodes {
                                    ...JcrNodeIdentity
                                    children {
                                        nodes {
                                            ...JcrNodeIdentity
                                            url
                                            thumbnailUrl(name: "thumbnail", checkIfExists: true)
                                            content: children(names: ["jcr:content"]) {
                                                nodes {
                                                    ...JcrNodeIdentity
                                                    mimeType: property(name: "jcr:mimeType") {
                                                        value
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
`;

export const GET_SUBMISSION_COUNT = gql`
    query GetSubmissionCount($countQuery: String!, $workspace: Workspace = LIVE) {
        jcr(workspace: $workspace) {
            nodesByQuery(
                query: $countQuery
                queryLanguage: SQL2
                limit: 1
                offset: 0
            ) {
                pageInfo {
                    totalCount
                }
            }
        }
    }
`;

export const DELETE_SUBMISSIONS = gql`
    mutation DeleteSubmissions($submissionsQuery: String!, $workspace: Workspace = LIVE) {
        jcr(workspace: $workspace) {
            mutateNodesByQuery(
                query: $submissionsQuery
                queryLanguage: SQL2
            ) {
                delete
            }
        }
    }
`;

/**
 * Removes a form's whole entry from the Results page: the fmdb:formResults node with its ACL
 * and whatever submissions it still holds. The form's next submission recreates the node.
 */
export const DELETE_FORM_RESULTS = gql`
    mutation DeleteFormResults($pathOrId: String!, $workspace: Workspace = LIVE) {
        jcr(workspace: $workspace) {
            deleteNode(pathOrId: $pathOrId)
        }
    }
`;

/**
 * The forms, among those whose live reference does not resolve, that still stand in EDIT: their
 * entries are "not published" rather than "deleted". The statement comes from buildFormsInEditQuery.
 */
export const GET_FORMS_IN_EDIT = gql`
    ${JCR_NODE_IDENTITY}
    query GetFormsInEdit($formsQuery: String!, $language: String!) {
        jcr(workspace: EDIT) {
            nodesByQuery(query: $formsQuery, queryLanguage: SQL2) {
                nodes {
                    ...JcrNodeIdentity
                    displayName(language: $language)
                }
            }
        }
    }
`;

export const GET_FORM_FIELD_LABELS = gql`
    ${JCR_NODE_IDENTITY}
    query GetFormFieldLabels($formUuid: String!, $language: String!, $optionsLanguage: String, $workspace: Workspace = LIVE) {
        jcr(workspace: $workspace) {
            nodeById(uuid: $formUuid) {
                ...JcrNodeIdentity
                fields: children(names: ["fields"]) {
                    nodes {
                        ...JcrNodeIdentity
                        descendants(
                            typesFilter: {types: ["fmdbmix:formElement"], multi: ANY}
                        ) {
                            nodes {
                                ...JcrNodeIdentity
                                name
                                displayName(language: $language)
                                isDate: isNodeType(type: {types: ["fmdbmix:dateField"]})
                                isDatetime: isNodeType(type: {types: ["fmdbmix:datetimeLocalField"]})
                                nonSubmittable: isNodeType(type: {types: ["fmdbmix:nonSubmittable"]})
                                options: property(name: "options", language: $optionsLanguage) {
                                    values
                                }
                            }
                        }
                    }
                }
            }
        }
    }
`;

/**
 * The forms of the site the imported results can attach to, unpublished ones included, and the default
 * language of the site, where the options of a choice field are always held: the statement comes from
 * buildSiteFormsQuery (import.utils.ts), the variables from siteFormsVariables.
 */
export const GET_SITE_FORMS = gql`
    ${JCR_NODE_IDENTITY}
    query GetSiteForms($formsQuery: String!, $language: String!, $sitePath: String!) {
        jcr(workspace: EDIT) {
            nodesByQuery(query: $formsQuery, queryLanguage: SQL2) {
                nodes {
                    ...JcrNodeIdentity
                    displayName(language: $language)
                }
            }
            site: nodeByPath(path: $sitePath) {
                ...JcrNodeIdentity
                defaultLanguage: property(name: "j:defaultLanguage") {
                    value
                }
            }
        }
    }
`;
