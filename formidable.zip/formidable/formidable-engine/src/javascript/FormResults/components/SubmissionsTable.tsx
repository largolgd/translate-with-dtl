import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {useQuery} from '@apollo/client';
import {
    Button,
    Loader,
    Paper,
    SortIndicator,
    Table,
    TableBody,
    TableBodyCell,
    TableHead,
    TableHeadCell,
    TablePagination,
    TableRow,
    Typography,
    Visibility
} from '@jahia/moonstone';
import {useTranslation} from 'react-i18next';
import {GET_SUBMISSIONS} from '../graphql';
import {
    buildSubmissionsQuery,
    formatDate,
    parseSubmissionNode,
    type FormResultsNode,
    type SubmissionRow
, type GqlSubmissionNode, nextEntryIndex} from '../FormResults.utils';

interface SubmissionsTableProps {
    formResults: FormResultsNode;
    /** Display order of the source form's fields; submissions are parsed in that order. */
    fieldOrder: string[];
    selectedSubmission: SubmissionRow | null;
    onSelectSubmission: (submission: SubmissionRow | null) => void;
    onRegisterRefresh: (refresh: (() => Promise<unknown>) | null) => void;
    /** The left arrow hands the focus back, to the list of forms. */
    onMoveLeft?: () => void;
    /** Hands the app the way in from the list: the selected submission takes the focus, else the first one is selected. */
    onRegisterEnter?: (enter: (() => void) | null) => void;
}

const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

export const SubmissionsTable = ({
    formResults,
    selectedSubmission,
    fieldOrder,
    onSelectSubmission,
    onRegisterRefresh,
    onMoveLeft,
    onRegisterEnter
}: SubmissionsTableProps) => {
    const {t} = useTranslation('formidable-engine');

    const [currentPage, setCurrentPage] = useState(1);
    const [pageSize, setPageSize] = useState(25);
    const [sortBy] = useState('created');
    const [sortDirection, setSortDirection] = useState<'ascending' | 'descending'>('descending');

    const submissionsQuery = useMemo(
        () => buildSubmissionsQuery(formResults.path, sortBy, sortDirection),
        [formResults.path, sortBy, sortDirection]
    );

    const offset = (currentPage - 1) * pageSize;

    const {loading, error, data, refetch} = useQuery(GET_SUBMISSIONS, {
        variables: {
            submissionsQuery,
            limit: pageSize,
            offset,
            workspace: 'LIVE'
        },
        fetchPolicy: 'network-only'
    });

    const queryResult = data?.jcr?.nodesByQuery;
    const totalCount = queryResult?.pageInfo?.totalCount ?? 0;
    const totalPages = Math.ceil(totalCount / pageSize);

    const submissions: SubmissionRow[] = useMemo(() => {
        const nodes = queryResult?.nodes ?? [];
        return nodes.map((node: GqlSubmissionNode) => parseSubmissionNode(node, fieldOrder));
    }, [queryResult, fieldOrder]);

    useEffect(() => {
        onRegisterRefresh(() => refetch());

        return () => {
            onRegisterRefresh(null);
        };
    }, [onRegisterRefresh, refetch]);

    useEffect(() => {
        if (!selectedSubmission) {
            return;
        }

        const updatedSelection = submissions.find(submission => submission.uuid === selectedSubmission.uuid);
        if (updatedSelection && updatedSelection !== selectedSubmission) {
            onSelectSubmission(updatedSelection);
        }
    }, [onSelectSubmission, selectedSubmission, submissions]);

    useEffect(() => {
        // During page transitions Apollo can briefly expose an empty result while the next page is loading.
        // Clamping the page number in that transient state sends the user back to page 1.
        if (loading || !queryResult?.pageInfo) {
            return;
        }

        if (totalPages === 0 && currentPage !== 1) {
            // eslint-disable-next-line @eslint-react/hooks-extra/no-direct-set-state-in-use-effect -- deliberate clamp against async query results
            setCurrentPage(1);
            return;
        }

        if (totalPages > 0 && currentPage > totalPages) {
            // eslint-disable-next-line @eslint-react/hooks-extra/no-direct-set-state-in-use-effect -- deliberate clamp against async query results
            setCurrentPage(totalPages);
        }
    }, [currentPage, loading, queryResult?.pageInfo, totalPages]);

    const tableRef = useRef<HTMLDivElement | null>(null);
    // Roving tabindex: the selected row is the one Tab reaches, or the first while none is selected.
    const isTabStop = (uuid: string, index: number): boolean =>
        selectedSubmission ? selectedSubmission.uuid === uuid : index === 0;

    const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
        if (e.key === 'ArrowLeft') {
            e.preventDefault();
            onMoveLeft?.();
            return;
        }

        if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') {
            return;
        }

        e.preventDefault();

        if (submissions.length === 0) {
            return;
        }

        const currentIndex = selectedSubmission
            ? submissions.findIndex(s => s.uuid === selectedSubmission.uuid)
            : -1;

        onSelectSubmission(submissions[nextEntryIndex(submissions.length, currentIndex, e.key)]);
    }, [submissions, selectedSubmission, onSelectSubmission, onMoveLeft]);

    // The right arrow from the list of forms lands here: on the selected row, or on the first submission, which
    // it selects — the selection effect below then gives its row the focus. Pressed while the submissions are
    // still loading (the form was just selected), the move waits for them.
    const enterPendingRef = useRef(false);
    useEffect(() => {
        if (!onRegisterEnter) {
            return undefined;
        }

        onRegisterEnter(() => {
            if (submissions.length === 0) {
                // Only a load in progress is waited for: a form with no submission has nothing to land on
                enterPendingRef.current = loading;
            } else if (selectedSubmission) {
                tableRef.current?.querySelector<HTMLElement>(`[data-submission-uuid="${selectedSubmission.uuid}"]`)?.focus({preventScroll: true});
            } else {
                onSelectSubmission(submissions[0]);
            }
        });

        return () => onRegisterEnter(null);
    }, [onRegisterEnter, submissions, selectedSubmission, onSelectSubmission, loading]);

    // The table is not keyed per form: a move pending on one form must not land on the next one selected.
    useEffect(() => {
        enterPendingRef.current = false;
    }, [formResults.uuid]);

    useEffect(() => {
        if (enterPendingRef.current && submissions.length > 0) {
            enterPendingRef.current = false;
            onSelectSubmission(submissions[0]);
        }
    }, [submissions, onSelectSubmission]);

    useEffect(() => {
        if (!selectedSubmission || !tableRef.current) {
            return;
        }

        const row = tableRef.current.querySelector<HTMLElement>(`[data-submission-uuid="${selectedSubmission.uuid}"]`);
        if (row) {
            row.focus({preventScroll: true});
            row.scrollIntoView({block: 'nearest'});
        }
    }, [selectedSubmission]);


    if (loading) {
        return (
            <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', height: '200px'}}>
                <Loader size="big"/>
            </div>
        );
    }

    if (error) {
        return <Typography color="danger">{error.message}</Typography>;
    }

    if (submissions.length === 0 && currentPage === 1) {
        return (
            <div style={{textAlign: 'center', padding: '48px'}}>
                <Typography variant="heading" weight="bold">{t('formResults.empty.noSubmissions')}</Typography>
            </div>
        );
    }

    return (
        <Paper hasPadding={false} style={{display: 'flex', flexDirection: 'column', height: '100%', borderRadius: '0'}}>
            <div
                ref={tableRef}
                data-sel-role="submissions-table"
                style={{
                    flex: 1,
                    overflow: 'auto',
                    outline: 'none'
                }}
            >
                <Table
                    style={{
                        minWidth: '620px'
                    }}
                >
                    <TableHead>
                        <TableRow>
                            <TableHeadCell
                                width="180px"
                                style={{cursor: 'pointer'}}
                                onClick={() => setSortDirection(current => current === 'descending' ? 'ascending' : 'descending')}
                                iconEnd={<SortIndicator direction={sortDirection} isSorted/>}
                            >
                                {t('formResults.table.date')}
                            </TableHeadCell>
                            <TableHeadCell width="90px">{t('formResults.table.locale')}</TableHeadCell>
                            <TableHeadCell width="80px" textAlign="center">{t('formResults.table.files')}</TableHeadCell>
                            <TableHeadCell width="90px" textAlign="center">{t('formResults.table.filledFields')}</TableHeadCell>
                            <TableHeadCell width="110px" textAlign="right"/>
                        </TableRow>
                    </TableHead>

                    <TableBody>
                        {submissions.map((submission, index) => (
                            <TableRow
                                key={submission.uuid}
                                isHighlighted={selectedSubmission?.uuid === submission.uuid}
                                // Roving tabindex: the selected row is the one Tab reaches, or the first while
                                // none is; the arrow keys are handled on the rows, the native interactive elements.
                                tabIndex={isTabStop(submission.uuid, index) ? 0 : -1}
                                data-submission-uuid={submission.uuid}
                                onClick={() => onSelectSubmission(submission)}
                                onKeyDown={handleKeyDown}
                                style={{cursor: 'pointer', outline: 'none'}}
                            >
                                <TableBodyCell width="180px" isScrollable>
                                    {formatDate(submission.created)}
                                </TableBodyCell>
                                <TableBodyCell width="90px">
                                    {submission.locale ?? ''}
                                </TableBodyCell>
                                <TableBodyCell width="80px" textAlign="center">
                                    {submission.files.length}
                                </TableBodyCell>
                                <TableBodyCell width="90px" textAlign="center">
                                    {submission.fieldValues.length}
                                </TableBodyCell>
                                <TableBodyCell width="110px" textAlign="right">
                                    <Button
                                        variant="ghost"
                                        size="small"
                                        label={t('formResults.table.view')}
                                        icon={<Visibility/>}
                                        onClick={e => {
                                            e.stopPropagation();
                                            onSelectSubmission(submission);
                                        }}
                                    />
                                </TableBodyCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>

            <div style={{padding: '0 16px 16px'}}>
                <TablePagination
                    rowsPerPage={pageSize}
                    rowsPerPageOptions={PAGE_SIZE_OPTIONS}
                    onRowsPerPageChange={rowsPerPage => {
                        setPageSize(rowsPerPage);
                        setCurrentPage(1);
                    }}
                    totalNumberOfRows={totalCount}
                    currentPage={currentPage}
                    onPageChange={setCurrentPage}
                    label={{
                        rowsPerPage: t('formResults.table.rowsPerPage'),
                        of: t('formResults.table.of')
                    }}
                />
                <div style={{paddingTop: '8px'}}>
                    <Typography variant="caption">
                        {t('formResults.table.pageInfo', {
                            current: String(currentPage),
                            total: String(totalPages || 1),
                            // A number on purpose: 'count' is i18next's reserved plural
                            // option, and typing it as a string is what forced the old
                            // 'as any' here.
                            count: totalCount
                        })}
                    </Typography>
                </div>
            </div>
        </Paper>
    );
};
